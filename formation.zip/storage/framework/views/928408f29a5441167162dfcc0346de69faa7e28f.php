<?php $__env->startSection('content'); ?>
    <link rel="icon" type="image/png" sizes="16x16" href="dshb/images/favicon.png">
    <link rel="stylesheet" href="dshb/vendor/owl-carousel/css/owl.carousel.min.css">
    <link rel="stylesheet" href="dshb/vendor/owl-carousel/css/owl.theme.default.min.css">
    <link href="dshb/vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
    <link href="dshb/css/style.css" rel="stylesheet">
    </head>

    <body>
        <!--*******************
                Preloader start
            ********************-->
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div>
        <!--*******************
                Preloader end
            ********************-->


        <!--**********************************
                Main wrapper start
            ***********************************-->

        <div id="main-wrapper">

            <!--**********************************
                    Nav header start
                ***********************************-->
            <div class="nav-header">
                <a href="dshb/index.html" class="brand-logo">
                    <img class="logo-abbr" src="dshb/images/logo.png" alt="">
                    <img class="logo-compact" src="dshb/images/logo-text.png" alt="">
                    <img class="brand-title" src="dshb/images/logo-text.png" alt="">
                </a>

                <div class="nav-control">
                    <div class="hamburger">
                        <span class="line"></span><span class="line"></span><span class="line"></span>
                    </div>
                </div>
            </div>
            <!--**********************************
                    Nav header end
                ***********************************-->

            <!--**********************************
                    Header start
                ***********************************-->
            <div class="header">
                <div class="header-content">
                    <nav class="navbar navbar-expand">
                        <div class="collapse navbar-collapse justify-content-between">
                            <div class="header-left">
                                <div class="search_bar dropdown">
                                    <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                        <i class="mdi mdi-magnify"></i>
                                    </span>
                                    <div class="dropdown-menu p-0 m-0">
                                        <form>
                                            <input class="form-control" type="search" placeholder="Search"
                                                aria-label="Search">
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <ul class="navbar-nav header-right">
                                <li class="nav-item dropdown notification_dropdown">
                                    <a class="nav-link" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-bell"></i>
                                        <div class="pulse-css"></div>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <ul class="list-unstyled">
                                            <li class="media dropdown-item">
                                                <span class="success"><i class="ti-user"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Martin</strong> has added a <strong>customer</strong>
                                                            Successfully
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="primary"><i class="ti-shopping-cart"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Jennifer</strong> purchased Light Dashboard 2.0.</p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="danger"><i class="ti-bookmark"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Robin</strong> marked a <strong>ticket</strong> as
                                                            unsolved.
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="primary"><i class="ti-heart"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>David</strong> purchased Light Dashboard 1.0.</p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="success"><i class="ti-image"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong> James.</strong> has added a<strong>customer</strong>
                                                            Successfully
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                        </ul>
                                        <a class="all-notification" href="#">See all notifications <i
                                                class="ti-arrow-right"></i></a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown header-profile">
                                    <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-account"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">

                                        <a href="dshb/app-profile.html" class="dropdown-item">
                                            <i class="icon-user"></i>
                                            <span class="ml-2"><?php echo e($prf->nom); ?> <?php echo e($prf->prenom); ?> </span>
                                        </a>
                                        <a href="dshb/email-inbox.html" class="dropdown-item">
                                            <i class="icon-envelope-open"></i>
                                            <span class="ml-2">Inbox </span>
                                        </a>
                                        <a href="dshb/page-login.html" class="dropdown-item">
                                            <i class="icon-key"></i>
                                            <span class="ml-2">Logout </span>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <!--**********************************
                    Header end ti-comment-alt
                ***********************************-->

            <!--**********************************
                    Sidebar start
                ***********************************-->
            <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--**********************************
                    Sidebar end
                ***********************************-->

            <!--**********************************
                    Content body start
                ***********************************-->
            <div class="content-body">
                <!-- row -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Account status: </div>
                                        <div class="stat-digit">
                                            <?php if($prf->status == '0'): ?>
                                                <span class="badge bg-danger stat-digit text-white">Not verified</span>
                                            <?php else: ?>
                                                <span class="badge bg-success  text-white">verified</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success w-100" role="progressbar"
                                            aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Last income:</div>
                                        <div class="stat-digit"> <i class="fa fa-usd"></i>7800</div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-primary w-75" role="progressbar"
                                            aria-valuenow="78" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Daily trades:</div>
                                        <div class="stat-digit"> <i class="fa fa-usd"></i> 500</div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning w-50" role="progressbar"
                                            aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Total:</div>
                                        <div class="stat-digit"> <i class="fa fa-usd"></i>650</div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger w-65" role="progressbar"
                                            aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                        <div class="col-lg-12">
                            <div class="card">


                                <div class="col">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title">Account:</h4>
                                            <?php if(session()->has('success')): ?>
                                                <div class="alert alert-success">
                                                    <?php echo e(session()->get('success')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="card-body">
                                            <div class="row">

                                                <div class="col-xl-3">
                                                    <div class="nav flex-column nav-pills">
                                                        <a href="#v-pills-home" data-toggle="pill"
                                                            class="nav-link active show">Invite a friend</a>
                                                        <a href="#v-pills-profile" data-toggle="pill"
                                                            class="nav-link">Profile</a>
                                                        <a href="#v-pills-messages" data-toggle="pill"
                                                            class="nav-link">Messages</a>
                                                        <a href="#v-pills-settings" data-toggle="pill"
                                                            class="nav-link">Account verification</a>
                                                    </div>
                                                </div>
                                                <div class="col-xl-6 text-center ">
                                                    <div class="tab-content">
                                                        <div id="v-pills-home" class="tab-pane fade active show">
                                                            <p>Invite a friend using this code when signin:

                                                                <span
                                                                    class="badge bg-success text-white"><?php echo e($prf->inv_code); ?></span><br>
                                                                <!-- <img class="profile-img" src="<?php echo e($prf->url_img); ?>" alt="public/<?php echo e($prf->url_img); ?>"> -->


                                                            </p>
                                                        </div>
                                                        <div id="v-pills-profile" class="tab-pane fade text-center">
                                                            <div class="container mt-2">
                                                                <div class="row ">



                                                                    <div class="card-body px-4 ">
                                                                        <div class="col-lg-6 col-sm-8  mx-auto ">
                                                                            <form action="<?php echo e(url('/update')); ?>"
                                                                                method="POST">
                                                                                <?php echo csrf_field(); ?>
                                                                                <?php if($prf->status == '0'): ?>
                                                                                    <div class="form-group">
                                                                                        <label for="fullName">Nom</label>
                                                                                        <input type="text"
                                                                                            class="form-control rounded-0"
                                                                                            id="fullName"
                                                                                            value="<?php echo e($prf->nom); ?> "
                                                                                            placeholder="Entrez votre nom complet">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label
                                                                                            for="fullName">Prenom</label>
                                                                                        <input type="text"
                                                                                            class="form-control rounded-0"
                                                                                            id="fullName"
                                                                                            value="<?php echo e($prf->prenom); ?>"
                                                                                            placeholder="Entrez votre nom complet">
                                                                                    </div>


                                                                                    <div class="form-group">
                                                                                        <label for="email">Adresse
                                                                                            email</label>
                                                                                        <input type="email"
                                                                                            class="form-control rounded-0"
                                                                                            id="email" name="email"
                                                                                            value="<?php echo e($prf->email); ?>"
                                                                                            placeholder="Entrez votre adresse email">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="password">Nouveau mot
                                                                                            de passe</label>
                                                                                        <input type="password"
                                                                                            class="form-control rounded-0"
                                                                                            name="password" id="password"
                                                                                            placeholder="Entrez votre mot de passe">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label
                                                                                            for="passwordConfirm">Confirmez
                                                                                            votre mot de passe</label>
                                                                                        <input type="password"
                                                                                            class="form-control rounded-0"
                                                                                            name="passwordconfirm"
                                                                                            id="passwordConfirm"
                                                                                            placeholder="Confirmez votre mot de passe">
                                                                                    </div>
                                                                                <?php else: ?>
                                                                                    <div class="form-group">
                                                                                        <label for="password">Nouveau mot
                                                                                            de passe</label>
                                                                                        <input type="password"
                                                                                            class="form-control rounded-0"
                                                                                            id="password" name="password"
                                                                                            placeholder="Entrez votre mot de passe">
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label
                                                                                            for="passwordConfirm">Confirmez
                                                                                            votre mot de passe</label>
                                                                                        <input type="password"
                                                                                            class="form-control rounded-0"
                                                                                            id="passwordconfirm"
                                                                                            name="passwordconfirm"
                                                                                            placeholder="Confirmez votre mot de passe">
                                                                                    </div>
                                                                                <?php endif; ?>


                                                                                <div class="form-group">
                                                                                    <label for="password">Statut du
                                                                                        compte</label>
                                                                                    <br>
                                                                                    <?php if($prf->status == '0'): ?>
                                                                                        <span
                                                                                            class="badge bg-danger  text-white">Not
                                                                                            verified</span>
                                                                                    <?php else: ?>
                                                                                        <span
                                                                                            class="badge bg-success stat-digit text-white">verified</span>
                                                                                    <?php endif; ?>
                                                                                </div>

                                                                                <div class="form-group">
                                                                                    <?php if(session()->has('status')): ?>
                                                                                        <div class="alert alert-success">
                                                                                            <?php echo e(session()->get('status')); ?>

                                                                                        </div>
                                                                                    <?php endif; ?>


                                                                                    <button type="submit"
                                                                                        class="btn  text-white btn-block rounded-1 py-2"
                                                                                        style="background-color: #593bdb;">Update</button>

                                                                                </div>
                                                                            </form>

                                                                        </div>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            </p>
                                                        </div>

                                                        <div id="v-pills-messages" class="tab-pane fade">


                                                            <!-- row -->
                                                            <div class="row">
                                                                <div class="col-lg-12">
                                                                    <div class="card">
                                                                        <div class="card-body">


                                                                            <div class="mail-list  btn-group">
                                                                                <a href="email-inbox.html"
                                                                                    class="list-group-item active"><i
                                                                                        class="fa fa-inbox font-18 align-middle mr-2"></i>
                                                                                    Inbox <span
                                                                                        class="badge badge-primary badge-sm float-right"><?php echo e($count); ?></span>
                                                                                </a>
                                                                                <button class="btn btn-dark"
                                                                                    style="margin-left:-2px"
                                                                                    style="padding-bottom: -1px"
                                                                                    type="button"><i
                                                                                        class="ti-reload"></i>
                                                                                </button>


                                                                            </div>

                                                                            <div class="modal fade" id="exampleModal"
                                                                                tabindex="-1"
                                                                                aria-labelledby="exampleModalLabel"
                                                                                aria-hidden="true">
                                                                                <div class="modal-dialog">
                                                                                    <div class="modal-content">
                                                                                        <div class="modal-header">
                                                                                            <h5 class="modal-title"
                                                                                                id="exampleModalLabel">
                                                                                                Modal title</h5>
                                                                                            <button type="button"
                                                                                                class="close"
                                                                                                data-dismiss="modal"
                                                                                                aria-label="Close">
                                                                                                <span
                                                                                                    aria-hidden="true">&times;</span>
                                                                                            </button>
                                                                                        </div>
                                                                                        <div class="modal-body">
                                                                                            ...
                                                                                        </div>
                                                                                        <div class="modal-footer">
                                                                                            <button type="button"
                                                                                                class="btn btn-secondary"
                                                                                                data-dismiss="modal">Close</button>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="">

                                                                                <div class="email-list mt-4">

                                                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <div class="message">
                                                                                            <div>
                                                                                                <div
                                                                                                    class="d-flex message-single">
                                                                                                    <div
                                                                                                        class="custom-control custom-checkbox pl-4">
                                                                                                        <input
                                                                                                            type="checkbox">
                                                                                                    </div>
                                                                                                    <div class="ml-2">
                                                                                                        <button
                                                                                                            class="border-0 bg-transparent align-middle p-0"><i
                                                                                                                class="fa fa-star"
                                                                                                                aria-hidden="true"></i></button>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <a class="col-mail col-mail-2"
                                                                                                    data-toggle="modal"
                                                                                                    data-target="#exampleModal">
                                                                                                    <div class="subject">
                                                                                                        <?php echo e($datas->message); ?>

                                                                                                    </div>
                                                                                                    <div class="date">
                                                                                                        11:49 am</div>
                                                                                                </a>
                                                                                            </div>

                                                                                        </div>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                                                </div>
                                                                                <!-- panel -->
                                                                                <div class="row mt-4 m-4 mx-sm-4">
                                                                                    <?php echo e($data->links('paginate')); ?>

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>



                                                        </div>
                                                        <div id="v-pills-settings" class="tab-pane fade">
                                                            <?php if($prf->status == '0'): ?>
                                                                <form action="<?php echo e(url('/verify')); ?>" method="post"
                                                                    enctype="multipart/form-data">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="form-group">
                                                                        <div class="input-group mb-3">

                                                                            <div class="custom-file">
                                                                                <input type="file"
                                                                                    class="custom-file-input"
                                                                                    id="inputGroupFile01" name="file">
                                                                                <label class="custom-file-label"
                                                                                    for="inputGroupFile01">Choose
                                                                                    file</label>
                                                                            </div>

                                                                        </div>


                                                                    </div>
                                                                    <div class="form-group">
                                                                        <label for="confirmation"
                                                                            class="col-form-label">Wallet adress:</label>
                                                                        <textarea class="form-control" id="wallet" name="wallet"></textarea>
                                                                    </div>

                                                                    <?php if(session()->has('status')): ?>
                                                                        <div class="alert alert-success">
                                                                            <?php echo e(session()->get('status')); ?>

                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <button type="submit"
                                                                        class="btn btn-primary">Confirm</button>
                                                                </form>
                                                            <?php else: ?>
                                                                <?php if($invited->count() == 0): ?>
                                                                    <span class="badge bg-success text-white">to complete
                                                                        the verification steps, you need to invite at least
                                                                        1 friend to join us.</span>
                                                                <?php else: ?>
                                                                    <span
                                                                        class="badge bg-success text-white">verified</span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>
                            <!-- /# card -->
                        </div>
                        <!-- /# column -->
                    </div>




                </div>
            </div>
            <!--**********************************
                    Content body end
                ***********************************-->


            <!--**********************************
                    Footer start
                ***********************************-->
            <div class="footer">
                <div class="copyright">
                    <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Quixkit</a> 2019</p>
                    <p>Distributed by <a href="https://themewagon.com/" target="_blank">Themewagon</a></p>
                </div>
            </div>
            <!--**********************************
                    Footer end
                ***********************************-->

            <!--**********************************
                   Support ticket button start
                ***********************************-->

            <!--**********************************
                   Support ticket button end
                ***********************************-->


        </div>
    </body>
    <script src="dshb/vendor/global/global.min.js"></script>
    <script src="dshb/js/quixnav-init.js"></script>
    <script src="dshb/js/custom.min.js"></script>


    <!-- Vectormap -->
    <script src="dshb/vendor/raphael/raphael.min.js"></script>
    <script src="dshb/vendor/morris/morris.min.js"></script>


    <script src="dshb/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="dshb/vendor/chart.js/Chart.bundle.min.js"></script>

    <script src="dshb/vendor/gaugeJS/dist/gauge.min.js"></script>

    <!--  flot-chart js -->
    <script src="dshb/vendor/flot/jquery.flot.js"></script>
    <script src="dshb/vendor/flot/jquery.flot.resize.js"></script>

    <!-- Owl Carousel -->
    <script src="dshb/vendor/owl-carousel/js/owl.carousel.min.js"></script>

    <!-- Counter Up -->
    <script src="dshb/vendor/jqvmap/js/jquery.vmap.min.js"></script>
    <script src="dshb/vendor/jqvmap/js/jquery.vmap.usa.js"></script>
    <script src="dshb/vendor/jquery.counterup/jquery.counterup.min.js"></script>


    <script src="dshb/js/dashboard/dashboard-1.js"></script>
    <!--**********************************
                Main wrapper end

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SloumaCh\Desktop\formation with ahmed\Nouveau dossier\formation\resources\views/profile.blade.php ENDPATH**/ ?>