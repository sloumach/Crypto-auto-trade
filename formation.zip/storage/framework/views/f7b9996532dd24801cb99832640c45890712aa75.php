<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css
    ">
</head>
<body>
<div class="container">
    <?php if(empty($data)): ?>
    <th>No transaction</th>

    <?php else: ?>


    <table class="table table-striped table-bordered table-hover">
        <thead class="bg-primary text-light">
          <tr>
            <th>ID</th>
            <th>User ID</th>
            <th>Amount</th>
            <th>Transaction ID</th>
            <th>Status</th>
            <th>Type</th>
            <th>Created At</th>
            <th>Actions:</th>

          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($datas->id); ?></td>
            <td><?php echo e($datas->id_user); ?></td>
            <td><?php echo e($datas->montant); ?></td>
            <td><?php echo e($datas->txid); ?></td>
            <td><span class="badge bg-warning">waiting</span></td>
            <?php if( $datas->type =='0' ): ?>
            <td>Deposit</td>
            <?php else: ?>
            <td>withdraw</td>
            <?php endif; ?>

            <td><?php echo e($datas->created_at); ?></td>
            <td><?php echo e($datas->created_at); ?></td>
            <td><button type="button" class="btn btn-success accept-btn" data-amount="<?php echo e($datas->montant); ?>" data-user="<?php echo e($datas->id_user); ?>" id="<?php echo e($datas->id); ?>">Accept</button>
                <button type="button" class="btn btn-danger decline-btn" data-user="<?php echo e($datas->id_user); ?>" data-amount="<?php echo e($datas->montant); ?>" id="<?php echo e($datas->id); ?>">Decline</button></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php endif; ?>
</div>




</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>

    $(document).ready(function() {
      $('.accept-btn').click(function() {
        var id = $(this).attr('id');
        var amount = $(this).data('amount');
        var id_user = $(this).data('user');
        $.ajax({
          type: "POST",
          url: "/addfunds",
          headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  },
          data: {
            id: id,
            amount: amount,
            id_user: id_user,
            action: 'accept'
          },
          success: function(data) {
            // Handle success response here
            console.log(data);
          },
          error: function(xhr, status, error) {
            // Handle error response here
            console.log(xhr.responseText);
          }
        });
      });

      $('.decline-btn').click(function() {
        var id = $(this).attr('id');
        var amount = $(this).data('amount');
        var id_user = $(this).data('user');
        $.ajax({
          type: "POST",
          url: "/addfunds",
          headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  },
          data: {
            id: id,
            amount: amount,
            id_user: id_user,
            action: 'decline'
          },
          success: function(data) {
            // Handle success response here
            console.log(data);
          },
          error: function(xhr, status, error) {
            // Handle error response here
            console.log(xhr.responseText);
          }
        });
      });
    });
  </script>

</html>
<?php /**PATH C:\xampp\htdocs\formation\resources\views/adddmin.blade.php ENDPATH**/ ?>