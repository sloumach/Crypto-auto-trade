<div class="col-lg-3 col-sm-6">
    <div class="card">
        <div class="stat-widget-two card-body">
            <div class="stat-content">
                <div class="stat-text">Account status: </div>
                <div class="stat-digit">
                    <?php if($prf->status == '0'): ?>
                        <span class="badge bg-danger stat-digit text-white">Not verified</span>
                    <?php endif; ?>
                    <?php if($prf->status == '2'): ?>
                        <span class="badge bg-warning stat-digit text-white">Pending</span>
                    <?php endif; ?>
                    <?php if($prf->status == '1'): ?>
                        <span class="badge bg-success  text-white">verified</span>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>
<div class="col-lg-3 col-sm-6">
    <div class="card">
        <div class="stat-widget-two card-body">
            <div class="stat-content">
                <div class="stat-text">Last income:</div>
                <?php if(empty($lasttrade)): ?>
                <div class="stat-digit"> <i class="fa fa-usd"></i>null</div>


                <?php else: ?>
                <div class="stat-digit"> <i class="fa fa-usd"></i><?php echo e($lasttrade->profit); ?></div>
                                <?php endif; ?>
            </div>
            <div class="progress">
                <div class="progress-bar progress-bar-primary w-75" role="progressbar" aria-valuenow="78"
                    aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-3 col-sm-6">
    <div class="card">
        <div class="stat-widget-two card-body">
            <div class="stat-content">
                <div class="stat-text">Last traded amount:</div>
                <?php if(empty($lasttrade)): ?>
                <div class="stat-digit"> <i class="fa fa-usd"></i> null</div>
                <?php else: ?>
<div class="stat-digit"> <i class="fa fa-usd"></i> <?php echo e($lasttrade->range_trade); ?></div>
                <?php endif; ?>

            </div>
            <div class="progress">
                <div class="progress-bar progress-bar-warning w-50" role="progressbar" aria-valuenow="50"
                    aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-3 col-sm-6">
    <div class="card">
        <div class="stat-widget-two card-body">
            <div class="stat-content">
                <div class="stat-text">Total:</div>
                <div class="stat-digit"> <i class="fa fa-usd"></i><?php echo e($prf->somme); ?></div>
            </div>
            <div class="progress">
                <div class="progress-bar progress-bar-danger w-65" role="progressbar" aria-valuenow="65"
                    aria-valuemin="0" aria-valuemax="100"></div>
            </div>
        </div>
    </div>
    <!-- /# card -->
</div>
<?php /**PATH C:\xampp\htdocs\formation\resources\views/topbody.blade.php ENDPATH**/ ?>