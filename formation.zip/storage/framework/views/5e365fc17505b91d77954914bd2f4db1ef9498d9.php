<?php $__env->startSection('content'); ?>



    </head>

    <body>

        <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--**********************************
                Sidebar end
            ***********************************-->

            <!--**********************************
                Content body start
            ***********************************-->
            <div class="content-body">
                <!-- row -->
                <div class="container-fluid">
                    <div class="row">
                       <?php echo $__env->make('topbody',['lasttrade' => $lasttrade,  'prf'=>$prf], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="container">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Trades history:</h4>
                                </div>
                                <div class="card-body">

                                    <div class="table-responsive ">
                                        <table class="text-dark table  table-bordered  ">
                                            <thead>
                                                <tr class="border-dark text-center">
                                                    <th class="border-dark">Trade ID</th>
                                                    <th class="border-dark">Trade info</th>
                                                    <th class="border-dark">Trade status</th>
                                                    <th class="border-dark">Trade date</th>
                                                    <th class="border-dark">Trade time entry</th>
                                                    <th class="border-dark">Trade time closure</th>
                                                    <th class="border-dark">Trade profit</th>

                                                </tr>
                                            </thead>
                                            <tbody class="text-white">
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->status == '1'): ?>
                                                    <tr class="text-center bg-success">
                                                    <?php else: ?>
                                                    <tr class="text-center bg-warning">
                                                    <?php endif; ?>
                                                        <th><?php echo e($item->id); ?></th>
                                                        <td>USDT-><?php echo e($item->crypto); ?></td>
                                                        <?php if($item->status == '0'): ?>
                                                            <td class="text-center "><span
                                                                    class=" alert alert-warning bg-warning text-center m-1 text-white ">Queue</span>
                                                            </td>
                                                        <?php endif; ?>
                                                        <?php if($item->status == '1'): ?>
                                                            <td class="text-center "><span
                                                                    class=" badge badge-success bg-success text-center   text-white ">Completed</span>
                                                            </td>
                                                        <?php endif; ?>
                                                        <td><?php echo e($item->created_at); ?></td>
                                                        <td class="color-primary">21.03 (GMT+2)</td>
                                                        <td class="color-primary">21.05 (GMT+2)</td>
                                                        <?php if($item->status == '0'): ?>
                                                            <td class="color-primary">- </td>
                                                        <?php endif; ?>
                                                        <?php if($item->status == '1'): ?>
                                                            <td class="color-primary"><?php echo e($item->income); ?>%</td>
                                                        <?php endif; ?>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                        </div>



                        <!-- /# card -->


                    </div> <!-- /# column -->
                </div>






                <!--**********************************
                Content body end
            ***********************************-->


                <!--**********************************
                Footer start
            ***********************************-->
                <div class="footer">
                    <div class="copyright">
                        <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Quixkit</a> 2019</p>
                        <p>Distributed by <a href="https://themewagon.com/" target="_blank">Themewagon</a></p>
                    </div>
                </div>
                <!--**********************************
                Footer end
            ***********************************-->

                <!--**********************************
               Support ticket button start
            ***********************************-->

                <!--**********************************
               Support ticket button end
            ***********************************-->


            </div>
    </body>
    <script src="dshb/vendor/global/global.min.js"></script>
    <script src="dshb/js/quixnav-init.js"></script>
    <script src="dshb/js/custom.min.js"></script>



    <!--**********************************
            Main wrapper end
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\formation\resources\views/tradeshist.blade.php ENDPATH**/ ?>