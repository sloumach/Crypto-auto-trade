<!--**********************************
            Sidebar start
        ***********************************-->

<div class="quixnav">
    <div class="quixnav-scroll">
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li><a class="" href="<?php echo e(url('/profile')); ?>" aria-expanded="false"><i
                        class="icon icon-single-04"></i><span class="nav-text">Account</span></a>

            </li>

            <li><a class="" href="<?php echo e(url('/market')); ?>" aria-expanded="false"><i
                        class="icon icon-app-store"></i><span class="nav-text">Market</span></a>
            </li>
            <li><a class="" href="<?php echo e(url('/settrade')); ?>" aria-expanded="false"><i
                        class="icon icon-chart-bar-33"></i><span class="nav-text">Set trade</span></a>

            </li>






            <li><a class="" href="<?php echo e(url('/tradeshist')); ?>" aria-expanded="false"><i
                        class="icon icon-form"></i><span class="nav-text">Trades history</span></a>
            </li>


            <li><a class="" href="<?php echo e(url('/funds')); ?>" aria-expanded="false"><i
                        class="icon icon-layout-25"></i><span class="nav-text">Funds</span></a>

            </li>

            <li><a class="" href="<?php echo e(url('/logout')); ?>" aria-expanded="false"><i
                        class="icon icon-single-copy-06"></i><span class="nav-text">Logout</span></a>

            </li>
        </ul>
    </div>


</div>

<!--**********************************
            Sidebar end
        ***********************************-->
<?php /**PATH C:\Users\SloumaCh\Desktop\formation with ahmed\Nouveau dossier\formation\resources\views/navbar.blade.php ENDPATH**/ ?>