<?php $__env->startSection('content'); ?>
    <link rel="icon" type="image/png" sizes="16x16" href="dshb/images/favicon.png">
    <link rel="stylesheet" href="dshb/vendor/owl-carousel/css/owl.carousel.min.css">
    <link rel="stylesheet" href="dshb/vendor/owl-carousel/css/owl.theme.default.min.css">
    <link href="dshb/vendor/jqvmap/css/jqvmap.min.css" rel="stylesheet">
    <link href="dshb/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="dshb/css/style_form.css" />

    </head>

    <body>
        <!--*******************
            Preloader start
        ********************-->
        <div id="preloader">
            <div class="sk-three-bounce">
                <div class="sk-child sk-bounce1"></div>
                <div class="sk-child sk-bounce2"></div>
                <div class="sk-child sk-bounce3"></div>
            </div>
        </div>
        <!--*******************
            Preloader end
        ********************-->


        <!--**********************************
            Main wrapper start
        ***********************************-->

        <div id="main-wrapper">

            <!--**********************************
                Nav header start
            ***********************************-->
            <div class="nav-header">
                <a href="dshb/index.html" class="brand-logo">
                    <img class="logo-abbr" src="dshb/images/logo.png" alt="">
                    <img class="logo-compact" src="dshb/images/logo-text.png" alt="">
                    <img class="brand-title" src="dshb/images/logo-text.png" alt="">
                </a>

                <div class="nav-control">
                    <div class="hamburger">
                        <span class="line"></span><span class="line"></span><span class="line"></span>
                    </div>
                </div>
            </div>
            <!--**********************************
                Nav header end
            ***********************************-->

            <!--**********************************
                Header start
            ***********************************-->
            <div class="header">
                <div class="header-content">
                    <nav class="navbar navbar-expand">
                        <div class="collapse navbar-collapse justify-content-between">
                            <div class="header-left">
                                <div class="search_bar dropdown">
                                    <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                        <i class="mdi mdi-magnify"></i>
                                    </span>
                                    <div class="dropdown-menu p-0 m-0">
                                        <form>
                                            <input class="form-control" type="search" placeholder="Search"
                                                aria-label="Search">
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <ul class="navbar-nav header-right">
                                <li class="nav-item dropdown notification_dropdown">
                                    <a class="nav-link" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-bell"></i>
                                        <div class="pulse-css"></div>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <ul class="list-unstyled">
                                            <li class="media dropdown-item">
                                                <span class="success"><i class="ti-user"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Martin</strong> has added a <strong>customer</strong>
                                                            Successfully
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="primary"><i class="ti-shopping-cart"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Jennifer</strong> purchased Light Dashboard 2.0.</p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="danger"><i class="ti-bookmark"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>Robin</strong> marked a <strong>ticket</strong> as
                                                            unsolved.
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="primary"><i class="ti-heart"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong>David</strong> purchased Light Dashboard 1.0.</p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                            <li class="media dropdown-item">
                                                <span class="success"><i class="ti-image"></i></span>
                                                <div class="media-body">
                                                    <a href="#">
                                                        <p><strong> James.</strong> has added a<strong>customer</strong>
                                                            Successfully
                                                        </p>
                                                    </a>
                                                </div>
                                                <span class="notify-time">3:20 am</span>
                                            </li>
                                        </ul>
                                        <a class="all-notification" href="#">See all notifications <i
                                                class="ti-arrow-right"></i></a>
                                    </div>
                                </li>
                                <li class="nav-item dropdown header-profile">
                                    <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                        <i class="mdi mdi-account"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right">

                                        <a href="dshb/app-profile.html" class="dropdown-item">
                                            <i class="icon-user"></i>
                                            <span class="ml-2"><?php echo e($prf->nom); ?> <?php echo e($prf->prenom); ?> </span>
                                        </a>
                                        <a href="dshb/email-inbox.html" class="dropdown-item">
                                            <i class="icon-envelope-open"></i>
                                            <span class="ml-2">Inbox </span>
                                        </a>
                                        <a href="dshb/page-login.html" class="dropdown-item">
                                            <i class="icon-key"></i>
                                            <span class="ml-2">Logout </span>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <!--**********************************
                Header end ti-comment-alt
            ***********************************-->

            <!--**********************************
                Sidebar start
            ***********************************-->
            <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--**********************************
                Sidebar end
            ***********************************-->

            <!--**********************************
                Content body start
            ***********************************-->
            <div class="content-body">
                <!-- row -->
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Account status: </div>
                                        <?php if($prf->status == '0'): ?>
                                            <span class="badge bg-danger stat-digit text-white">Not verified</span>
                                        <?php else: ?>
                                            <span class="badge bg-success text-white">verified</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success w-85" role="s"
                                            aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Last income:</div>
                                        <div class="stat-digit"> <i class="fa fa-usd"></i>7800</div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-primary w-75" role="progressbar"
                                            aria-valuenow="78" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Daily trades:</div>
                                        <div class="stat-digit"> <i class="fa fa-usd"></i> 500</div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-warning w-50" role="progressbar"
                                            aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6">
                            <div class="card">
                                <div class="stat-widget-two card-body">
                                    <div class="stat-content">
                                        <div class="stat-text">Total:</div>
                                        <div class="stat-digit"> <i class="fa fa-usd"></i>650</div>
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-danger w-65" role="progressbar"
                                            aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                </div>
                            </div>
                            <!-- /# card -->
                        </div>
                    </div>
                    <div class="container">
                        <div class="col-lg-12">
                            <div class="card ">
                                <div class="card-header justify-content-center">
                                    <a style="font-size: 14px;"
                                        class="badge badge-rounded badge-outline-secondary text-secondary">What to do:</a>

                                </div>
                                <?php if(session()->has('success')): ?>
                                    <div class="row justify-content-center">
                                        <span class="alert bg-success text-white">
                                            <?php echo e(session()->get('success')); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if(session()->has('failed')): ?>
                                    <div class="row justify-content-center">
                                        <span class="alert bg-danger text-white">
                                            <?php echo e(session()->get('failed')); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="card-body">

                                    <div class="row justify-content-center">
                                        <div class="col col-4-lg col-6-sm  ">
                                            <button type="button" class="btn btn-outline-secondary btn-block"
                                                data-toggle="modal" data-target="#transfertmodal">Transfert</button>

                                        </div>
                                        <div class="modal fade" id="transfertmodal" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <h5>Site wallet (USDT): Loremipsumdolorsitamet.</h5>
                                                        <form method="post" action="<?php echo e(url('/recharge')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label for="recipient-name"
                                                                    class="col-form-label">Amount:</label>
                                                                <input type="text" class="form-control" name="amount"
                                                                    id="recipient-name">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="message-text"
                                                                    class="col-form-label">Txid:</label>
                                                                <textarea class="form-control" name="txid" id="message-text"></textarea>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="confirmation" class="col-form-label">Password
                                                                    confirmation:</label>
                                                                <input type="password" name="password"
                                                                    class="form-control" id="password">
                                                            </div>
                                                            <button type="submit"
                                                                class="btn btn-primary">Confirm</button>
                                                        </form>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="modal fade" id="historymodal" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="table-responsive ">
                                                            <table class="text-dark table table-hover table-bordered  ">
                                                                <thead>
                                                                    <tr class="border-dark text-center">
                                                                        <th class="border-dark">ID:</th>
                                                                        <th class="border-dark">Amount</th>
                                                                        <th class="border-dark">Status</th>
                                                                        <th class="border-dark">type</th>
                                                                        <th class="border-dark">Date</th>


                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $hist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr class="text-center ">
                                                                            <th><?php echo e($item->id); ?></th>
                                                                            <td><?php echo e($item->montant); ?></td>
                                                                            <td class="text-center ">
                                                                                <?php if($item->status == '0'): ?>
                                                                                    <span
                                                                                        class=" alert alert-warning bg-warning text-center m-1 text-white ">Queue</span>
                                                                                <?php endif; ?>
                                                                                <?php if($item->status == '1'): ?>
                                                                                    <span
                                                                                        class=" alert alert-success bg-success text-center m-1 text-white ">Confirmed</span>
                                                                                <?php endif; ?>
                                                                                <?php if($item->status == '2'): ?>
                                                                                    <span
                                                                                        class=" alert alert-danger bg-danger text-center m-1 text-white ">Rejected</span>
                                                                                <?php endif; ?>
                                                                            </td>
                                                                            <td>
                                                                                <?php if($item->type == '0'): ?>
                                                                                <span
                                                                                    class=" alert alert-success bg-success text-center m-1 text-white ">Recharge</span>
                                                                            <?php endif; ?>
                                                                            <?php if($item->type == '1'): ?>
                                                                                <span
                                                                                    class=" alert alert-warning bg-warning text-center m-1 text-white ">Withdraw</span>
                                                                            <?php endif; ?>
                                                                        </td>
                                                                            <td class="color-primary">
                                                                                <?php echo e($item->created_at); ?></td>

                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                </tbody>
                                                            </table>
                                                        </div>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="modal fade" id="withdrawmodal" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="post" action="<?php echo e(url('/withdraw')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label for="recipient-name"
                                                                    class="col-form-label">Amount:</label>
                                                                <input type="text" class="form-control" name="amount"
                                                                    id="recipient-name">
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="confirmation" class="col-form-label">Password
                                                                    confirmation:</label>
                                                                <input type="password" class="form-control"
                                                                    name="password" id="password">
                                                            </div>
                                                            <button type="submit"
                                                                class="btn btn-primary">Confirm</button>
                                                        </form>

                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal">Close</button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col col-4-lg col-6-sm ">
                                            <button type="button" class="btn btn-outline-secondary btn-block "
                                                data-toggle="modal" data-target="#withdrawmodal">Withdraw</button>

                                        </div>

                                    </div>
                                    <div class="row justify-content-center mt-2">
                                        <div class="col col-12-lg col-12-sm ">
                                            <button type="button" class="btn btn-outline-secondary btn-block"
                                                data-toggle="modal" data-target="#historymodal">History</button>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>



                    <!-- /# card -->


                </div> <!-- /# column -->
            </div>






            <!--**********************************
                Content body end
            ***********************************-->


            <!--**********************************
                Footer start
            ***********************************-->
            <div class="footer">
                <div class="copyright">
                    <p>Copyright © Designed &amp; Developed by <a href="#" target="_blank">Quixkit</a> 2019</p>
                    <p>Distributed by <a href="https://themewagon.com/" target="_blank">Themewagon</a></p>
                </div>
            </div>
            <!--**********************************
                Footer end
            ***********************************-->

            <!--**********************************
               Support ticket button start
            ***********************************-->

            <!--**********************************
               Support ticket button end
            ***********************************-->


        </div>
    </body>
    <script src="dshb/js/jquery-3.2.1.min.js"></script>
    <!-- <script src="dshb/js/bootstrap.min.js"></script> -->
    <script src="dshb/js/jquery.slicknav.min.js"></script>
    <script src="dshb/js/owl.carousel.min.js"></script>
    <script src="dshb/js/jquery-ui.min.js"></script>
    <script src="dshb/js/main.js"></script>
    <script src="dshb/vendor/global/global.min.js"></script>
    <script src="dshb/js/quixnav-init.js"></script>
    <script src="dshb/js/custom.min.js"></script>
    <script src="dshb/js/js_form.js"></script>


    <!-- Vectormap -->
    <script src="dshb/vendor/raphael/raphael.min.js"></script>
    <script src="dshb/vendor/morris/morris.min.js"></script>


    <script src="dshb/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="dshb/vendor/chart.js/Chart.bundle.min.js"></script>

    <script src="dshb/vendor/gaugeJS/dist/gauge.min.js"></script>

    <!--  flot-chart js -->
    <script src="dshb/vendor/flot/jquery.flot.js"></script>
    <script src="dshb/vendor/flot/jquery.flot.resize.js"></script>

    <!-- Owl Carousel -->
    <script src="dshb/vendor/owl-carousel/js/owl.carousel.min.js"></script>

    <!-- Counter Up -->
    <script src="dshb/vendor/jqvmap/js/jquery.vmap.min.js"></script>
    <script src="dshb/vendor/jqvmap/js/jquery.vmap.usa.js"></script>
    <script src="dshb/vendor/jquery.counterup/jquery.counterup.min.js"></script>


    <script src="dshb/js/dashboard/dashboard-1.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"
        integrity="sha256-lSjKY0/srUM9BE3dPm+c4fBo1dky2v27Gdjm2uoZaL0=" crossorigin="anonymous"></script>
    <!--**********************************
            Main wrapper end
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SloumaCh\Desktop\formation with ahmed\Nouveau dossier\formation\resources\views/funds.blade.php ENDPATH**/ ?>