(function($) {
    'use strict'

    $('#timepicki').timepicki();

})(jQuery);